This zip folder contains two files:


1. "Project - topic 14_coin toss game.ipynb"

This file contains the Python script used for data analysis in this project.
Please open the script in Jupyter Notebook and execute the script in the order from the top to the bottom. 
The script may generate slightly different results in different executions, since there is some randomness involved in certain steps of the program.



2. "Project - topic 14_coin toss game.html"

This file is a copy of the program execution results stored in HTML format. The file is printed out from Jupyter Notebook. 
The excecution results displayed in this file should be consistent with what displayed in the final project report.